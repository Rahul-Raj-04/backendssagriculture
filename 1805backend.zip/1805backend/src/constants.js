export const DB_NAME = "SSAgriculture";
